from flask import Flask, render_template, request, jsonify, redirect, url_for, flash
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime, timedelta
import os
import json
from models import db, Vehicle, MaintenanceRecord, Prediction
from ml_model import predict_maintenance

app = Flask(__name__)
app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY', 'dev_key_for_testing')
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///vehicle_maintenance.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

# Initialize the database
db.init_app(app)

@app.before_first_request
def create_tables():
    db.create_all()

@app.route('/')
def index():
    # Get summary statistics
    total_vehicles = Vehicle.query.count()
    maintenance_due = Prediction.query.filter(
        Prediction.due_date <= datetime.now() + timedelta(days=30)
    ).count()
    
    # Get average mileage
    vehicles = Vehicle.query.all()
    if vehicles:
        avg_mileage = sum(v.mileage for v in vehicles) / len(vehicles)
    else:
        avg_mileage = 0
    
    # Get upcoming maintenance predictions
    upcoming_predictions = Prediction.query.filter(
        Prediction.due_date <= datetime.now() + timedelta(days=30)
    ).order_by(Prediction.due_date).limit(3).all()
    
    return render_template('index.html', 
                          total_vehicles=total_vehicles,
                          maintenance_due=maintenance_due,
                          avg_mileage=avg_mileage,
                          upcoming_predictions=upcoming_predictions)

@app.route('/vehicles')
def vehicles():
    all_vehicles = Vehicle.query.all()
    return render_template('vehicles.html', vehicles=all_vehicles)

@app.route('/vehicles/new', methods=['GET', 'POST'])
def new_vehicle():
    if request.method == 'POST':
        # Extract form data
        make = request.form.get('make')
        model = request.form.get('model')
        year = int(request.form.get('year'))
        license_plate = request.form.get('license')
        mileage = int(request.form.get('mileage'))
        last_maintenance_date = datetime.strptime(request.form.get('last_maintenance'), '%Y-%m-%d')
        
        # Get driving environment and style
        environments = []
        if request.form.get('urban'):
            environments.append('urban')
        if request.form.get('highway'):
            environments.append('highway')
        if request.form.get('rural'):
            environments.append('rural')
        
        driving_style = request.form.get('driving_style', 'moderate')
        
        # Create usage pattern JSON
        usage_pattern = {
            'environments': environments,
            'driving_style': driving_style,
            'avg_daily_miles': 30  # Default value
        }
        
        # Create new vehicle
        new_vehicle = Vehicle(
            make=make,
            model=model,
            year=year,
            license_plate=license_plate,
            mileage=mileage,
            last_maintenance_date=last_maintenance_date,
            usage_pattern=json.dumps(usage_pattern)
        )
        
        # Add initial maintenance record
        initial_record = MaintenanceRecord(
            vehicle=new_vehicle,
            date=last_maintenance_date,
            maintenance_type="Initial Service",
            mileage=mileage,
            description="Initial vehicle registration"
        )
        
        db.session.add(new_vehicle)
        db.session.add(initial_record)
        db.session.commit()
        
        flash('Vehicle added successfully!', 'success')
        return redirect(url_for('vehicles'))
    
    return render_template('new_vehicle.html')

@app.route('/predictions')
def predictions():
    all_predictions = Prediction.query.order_by(Prediction.due_date).all()
    return render_template('predictions.html', predictions=all_predictions)

@app.route('/predictions/generate', methods=['GET', 'POST'])
def generate_predictions():
    if request.method == 'POST':
        # Get prediction parameters
        prediction_type = request.form.get('prediction_type', 'all')
        timeframe = int(request.form.get('timeframe', 90))
        confidence_threshold = int(request.form.get('confidence_threshold', 70))
        include_historical = 'include_historical' in request.form
        seasonal_factors = 'seasonal_factors' in request.form
        driver_behavior = 'driver_behavior' in request.form
        
        # Clear existing predictions
        Prediction.query.delete()
        
        # Get all vehicles
        vehicles = Vehicle.query.all()
        
        # Generate new predictions for each vehicle
        for vehicle in vehicles:
            # Get maintenance history
            maintenance_history = MaintenanceRecord.query.filter_by(vehicle_id=vehicle.id).all()
            
            # Convert to format expected by ML model
            vehicle_data = {
                'id': vehicle.id,
                'make': vehicle.make,
                'model': vehicle.model,
                'year': vehicle.year,
                'mileage': vehicle.mileage,
                'last_maintenance_date': vehicle.last_maintenance_date,
                'maintenance_history': [
                    {
                        'date': record.date,
                        'type': record.maintenance_type,
                        'mileage': record.mileage
                    } for record in maintenance_history
                ],
                'usage_pattern': json.loads(vehicle.usage_pattern)
            }
            
            # Call prediction model
            prediction_results = predict_maintenance(
                vehicle_data, 
                prediction_type, 
                timeframe, 
                confidence_threshold,
                include_historical,
                seasonal_factors,
                driver_behavior
            )
            
            # Save predictions to database
            for result in prediction_results:
                new_prediction = Prediction(
                    vehicle_id=vehicle.id,
                    maintenance_type=result['maintenance_type'],
                    due_date=datetime.strptime(result['due_date'], '%Y-%m-%d'),
                    confidence=result['confidence'],
                    status='Upcoming'
                )
                db.session.add(new_prediction)
        
        db.session.commit()
        flash('Predictions generated successfully!', 'success')
        return redirect(url_for('predictions'))
    
    return render_template('generate_predictions.html')

@app.route('/api/vehicles', methods=['GET'])
def api_vehicles():
    vehicles = Vehicle.query.all()
    return jsonify([{
        'id': v.id,
        'make': v.make,
        'model': v.model,
        'year': v.year,
        'license_plate': v.license_plate,
        'mileage': v.mileage,
        'last_maintenance_date': v.last_maintenance_date.strftime('%Y-%m-%d')
    } for v in vehicles])

@app.route('/api/predictions', methods=['GET'])
def api_predictions():
    predictions = Prediction.query.all()
    return jsonify([{
        'id': p.id,
        'vehicle_id': p.vehicle_id,
        'vehicle': f"{p.vehicle.make} {p.vehicle.model}",
        'maintenance_type': p.maintenance_type,
        'due_date': p.due_date.strftime('%Y-%m-%d'),
        'confidence': p.confidence,
        'status': p.status
    } for p in predictions])

if __name__ == '__main__':
    app.run(debug=True)
