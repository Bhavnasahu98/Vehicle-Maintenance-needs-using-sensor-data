"use client"

import * as tf from "@tensorflow/tfjs"

// Define the types for our prediction parameters
interface PredictionParams {
  predictionType: string
  timeframe: number
  confidenceThreshold: number
}

// Define the vehicle data structure
interface VehicleData {
  id: string
  make: string
  model: string
  year: number
  mileage: number
  lastMaintenanceDate: Date
  maintenanceHistory: MaintenanceRecord[]
  usagePattern: UsagePattern
}

interface MaintenanceRecord {
  date: Date
  type: string
  mileage: number
  description: string
}

interface UsagePattern {
  averageDailyMiles: number
  averageSpeed: number
  environmentalFactors: string[]
  drivingStyle: string
}

// Sample vehicle data (in a real app, this would come from a database)
const sampleVehicleData: VehicleData[] = [
  {
    id: "1",
    make: "Toyota",
    model: "Camry",
    year: 2020,
    mileage: 35000,
    lastMaintenanceDate: new Date("2025-01-15"),
    maintenanceHistory: [
      {
        date: new Date("2024-07-10"),
        type: "Oil Change",
        mileage: 25000,
        description: "Regular oil change and filter replacement",
      },
      {
        date: new Date("2025-01-15"),
        type: "Tire Rotation",
        mileage: 32000,
        description: "Tire rotation and pressure check",
      },
    ],
    usagePattern: {
      averageDailyMiles: 30,
      averageSpeed: 45,
      environmentalFactors: ["urban", "moderate climate"],
      drivingStyle: "moderate",
    },
  },
  // Additional vehicles would be here
]

// Initialize the TensorFlow.js model
async function createModel(): Promise<tf.LayersModel> {
  // Create a simple sequential model
  const model = tf.sequential()

  // Add layers to the model
  model.add(
    tf.layers.dense({
      inputShape: [7], // Input features: age, mileage, time since last maintenance, etc.
      units: 12,
      activation: "relu",
    }),
  )

  model.add(
    tf.layers.dense({
      units: 8,
      activation: "relu",
    }),
  )

  model.add(
    tf.layers.dense({
      units: 4,
      activation: "relu",
    }),
  )

  model.add(
    tf.layers.dense({
      units: 1,
      activation: "sigmoid", // Output is a probability
    }),
  )

  // Compile the model
  model.compile({
    optimizer: tf.train.adam(),
    loss: "binaryCrossentropy",
    metrics: ["accuracy"],
  })

  return model
}

// Preprocess vehicle data for the model
function preprocessData(vehicle: VehicleData): number[] {
  const currentDate = new Date()
  const vehicleAge = currentDate.getFullYear() - vehicle.year
  const daysSinceLastMaintenance = Math.floor(
    (currentDate.getTime() - vehicle.lastMaintenanceDate.getTime()) / (1000 * 60 * 60 * 24),
  )
  const maintenanceFrequency = vehicle.maintenanceHistory.length / vehicleAge || 0

  // Normalize driving style to a number
  let drivingStyleFactor = 0.5
  if (vehicle.usagePattern.drivingStyle === "aggressive") {
    drivingStyleFactor = 0.8
  } else if (vehicle.usagePattern.drivingStyle === "conservative") {
    drivingStyleFactor = 0.3
  }

  // Environmental factor (simplified)
  const environmentalFactor = vehicle.usagePattern.environmentalFactors.includes("urban") ? 0.7 : 0.4

  return [
    vehicleAge / 10, // Normalize age
    vehicle.mileage / 100000, // Normalize mileage
    daysSinceLastMaintenance / 365, // Normalize days since last maintenance
    maintenanceFrequency / 5, // Normalize maintenance frequency
    vehicle.usagePattern.averageDailyMiles / 100, // Normalize daily miles
    drivingStyleFactor,
    environmentalFactor,
  ]
}

// Make predictions for a single vehicle
async function predictMaintenance(
  model: tf.LayersModel,
  vehicle: VehicleData,
  params: PredictionParams,
): Promise<
  {
    vehicleId: string
    vehicle: string
    maintenanceType: string
    dueDate: string
    confidence: number
  }[]
> {
  // Preprocess the vehicle data
  const features = preprocessData(vehicle)

  // Convert to tensor
  const inputTensor = tf.tensor2d([features])

  // Make prediction
  const prediction = model.predict(inputTensor) as tf.Tensor
  const confidenceValue = (await prediction.data())[0]

  // Clean up tensors
  inputTensor.dispose()
  prediction.dispose()

  // If confidence is below threshold, return empty array
  if (confidenceValue * 100 < params.confidenceThreshold) {
    return []
  }

  // Calculate due date based on prediction and timeframe
  const currentDate = new Date()
  const daysToAdd = Math.floor(confidenceValue * params.timeframe)
  const dueDate = new Date(currentDate)
  dueDate.setDate(dueDate.getDate() + daysToAdd)

  // Determine maintenance type based on mileage and history
  let maintenanceType = "Oil Change" // Default

  if (vehicle.mileage > 30000 && vehicle.mileage < 40000) {
    maintenanceType = "Brake Service"
  } else if (vehicle.mileage > 40000 && vehicle.mileage < 60000) {
    maintenanceType = "Transmission Service"
  } else if (vehicle.mileage % 5000 < 500) {
    maintenanceType = "Tire Rotation"
  }

  // Filter by prediction type if needed
  if (params.predictionType !== "all") {
    const isMajor = ["Transmission Service", "Engine Service", "Brake Service"].includes(maintenanceType)
    if ((params.predictionType === "major" && !isMajor) || (params.predictionType === "routine" && isMajor)) {
      return []
    }
  }

  // Format confidence level
  let confidenceLevel = "Medium"
  if (confidenceValue > 0.8) {
    confidenceLevel = "High"
  } else if (confidenceValue < 0.6) {
    confidenceLevel = "Low"
  }

  return [
    {
      vehicleId: vehicle.id,
      vehicle: `${vehicle.make} ${vehicle.model}`,
      maintenanceType,
      dueDate: dueDate.toLocaleDateString("en-US", { year: "numeric", month: "long", day: "numeric" }),
      confidence: confidenceLevel as any,
    },
  ]
}

// Main prediction function that will be exported
export async function runPredictionModel(params: PredictionParams): Promise<any[]> {
  try {
    // Initialize the model
    const model = await createModel()

    // In a real application, we would train the model here with historical data
    // For this example, we'll skip training and use the initialized model directly

    // Make predictions for all vehicles
    const allPredictions = []
    for (const vehicle of sampleVehicleData) {
      const predictions = await predictMaintenance(model, vehicle, params)
      allPredictions.push(...predictions)
    }

    // Sort predictions by due date
    allPredictions.sort((a, b) => {
      return new Date(a.dueDate).getTime() - new Date(b.dueDate).getTime()
    })

    return allPredictions
  } catch (error) {
    console.error("Error in prediction model:", error)
    throw error
  }
}
