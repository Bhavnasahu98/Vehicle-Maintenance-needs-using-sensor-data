from flask_sqlalchemy import SQLAlchemy
from datetime import datetime

db = SQLAlchemy()

class Vehicle(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    make = db.Column(db.String(50), nullable=False)
    model = db.Column(db.String(50), nullable=False)
    year = db.Column(db.Integer, nullable=False)
    license_plate = db.Column(db.String(20), unique=True, nullable=False)
    mileage = db.Column(db.Integer, nullable=False)
    last_maintenance_date = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)
    usage_pattern = db.Column(db.Text, nullable=True)  # JSON string
    
    # Relationships
    maintenance_records = db.relationship('MaintenanceRecord', backref='vehicle', lazy=True)
    predictions = db.relationship('Prediction', backref='vehicle', lazy=True)
    
    def __repr__(self):
        return f"<Vehicle {self.make} {self.model} ({self.license_plate})>"

class MaintenanceRecord(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    vehicle_id = db.Column(db.Integer, db.ForeignKey('vehicle.id'), nullable=False)
    date = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)
    maintenance_type = db.Column(db.String(100), nullable=False)
    mileage = db.Column(db.Integer, nullable=False)
    description = db.Column(db.Text, nullable=True)
    
    def __repr__(self):
        return f"<Maintenance {self.maintenance_type} for Vehicle {self.vehicle_id}>"

class Prediction(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    vehicle_id = db.Column(db.Integer, db.ForeignKey('vehicle.id'), nullable=False)
    maintenance_type = db.Column(db.String(100), nullable=False)
    due_date = db.Column(db.DateTime, nullable=False)
    confidence = db.Column(db.String(20), nullable=False)  # High, Medium, Low
    status = db.Column(db.String(20), nullable=False, default='Upcoming')  # Upcoming, Scheduled, Completed, Overdue
    
    def __repr__(self):
        return f"<Prediction {self.maintenance_type} for Vehicle {self.vehicle_id}>"
