import Link from "next/link"
import { Car, Filter, Plus, Search } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"

export default function VehiclesPage() {
  const vehicles = [
    {
      id: "1",
      make: "Toyota",
      model: "Camry",
      year: 2020,
      plate: "ABC-1234",
      mileage: 35000,
      lastMaintenance: "Jan 15, 2025",
      status: "Healthy",
    },
    {
      id: "2",
      make: "Ford",
      model: "F-150",
      year: 2019,
      plate: "XYZ-5678",
      mileage: 48000,
      lastMaintenance: "Feb 10, 2025",
      status: "Maintenance Soon",
    },
    {
      id: "3",
      make: "Honda",
      model: "CR-V",
      year: 2021,
      plate: "DEF-9012",
      mileage: 22000,
      lastMaintenance: "Mar 5, 2025",
      status: "Healthy",
    },
    {
      id: "4",
      make: "Chevrolet",
      model: "Silverado",
      year: 2018,
      plate: "GHI-3456",
      mileage: 65000,
      lastMaintenance: "Dec 20, 2024",
      status: "Maintenance Due",
    },
    {
      id: "5",
      make: "Nissan",
      model: "Altima",
      year: 2022,
      plate: "JKL-7890",
      mileage: 15000,
      lastMaintenance: "Apr 1, 2025",
      status: "Healthy",
    },
  ]

  return (
    <div className="flex min-h-screen flex-col">
      <header className="sticky top-0 z-10 flex h-16 items-center gap-4 border-b bg-background px-6">
        <Car className="h-6 w-6" />
        <h1 className="text-lg font-semibold">Vehicle Maintenance Predictor</h1>
        <nav className="ml-auto flex gap-4">
          <Link href="/" className="text-sm font-medium text-muted-foreground">
            Dashboard
          </Link>
          <Link href="/vehicles" className="text-sm font-medium">
            Vehicles
          </Link>
          <Link href="/predictions" className="text-sm font-medium text-muted-foreground">
            Predictions
          </Link>
          <Link href="/settings" className="text-sm font-medium text-muted-foreground">
            Settings
          </Link>
        </nav>
      </header>
      <main className="flex-1 p-6">
        <div className="grid gap-6">
          <div className="flex items-center justify-between">
            <h2 className="text-2xl font-bold tracking-tight">Vehicles</h2>
            <Button>
              <Plus className="mr-2 h-4 w-4" />
              Add Vehicle
            </Button>
          </div>
          <Card>
            <CardHeader>
              <CardTitle>Vehicle Fleet</CardTitle>
              <CardDescription>Manage and view all vehicles in your fleet</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex items-center gap-4 mb-6">
                <div className="relative flex-1">
                  <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                  <Input type="search" placeholder="Search vehicles..." className="pl-8" />
                </div>
                <Button variant="outline" size="icon">
                  <Filter className="h-4 w-4" />
                  <span className="sr-only">Filter</span>
                </Button>
              </div>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Vehicle</TableHead>
                    <TableHead>Year</TableHead>
                    <TableHead>License Plate</TableHead>
                    <TableHead>Mileage</TableHead>
                    <TableHead>Last Maintenance</TableHead>
                    <TableHead>Status</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {vehicles.map((vehicle) => (
                    <TableRow key={vehicle.id}>
                      <TableCell className="font-medium">
                        {vehicle.make} {vehicle.model}
                      </TableCell>
                      <TableCell>{vehicle.year}</TableCell>
                      <TableCell>{vehicle.plate}</TableCell>
                      <TableCell>{vehicle.mileage.toLocaleString()}</TableCell>
                      <TableCell>{vehicle.lastMaintenance}</TableCell>
                      <TableCell>
                        <span
                          className={`inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium ${
                            vehicle.status === "Healthy"
                              ? "bg-green-100 text-green-800"
                              : vehicle.status === "Maintenance Soon"
                                ? "bg-yellow-100 text-yellow-800"
                                : "bg-red-100 text-red-800"
                          }`}
                        >
                          {vehicle.status}
                        </span>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  )
}
