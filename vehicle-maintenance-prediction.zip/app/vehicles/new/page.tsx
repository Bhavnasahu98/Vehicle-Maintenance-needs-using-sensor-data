"use client"

import type React from "react"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, Car, Check } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

export default function NewVehiclePage() {
  const [submitted, setSubmitted] = useState(false)
  const [drivingStyle, setDrivingStyle] = useState("moderate")

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setSubmitted(true)
  }

  if (submitted) {
    return (
      <div className="flex min-h-screen flex-col">
        <header className="sticky top-0 z-10 flex h-16 items-center gap-4 border-b bg-background px-6">
          <Car className="h-6 w-6" />
          <h1 className="text-lg font-semibold">Vehicle Maintenance Predictor</h1>
          <nav className="ml-auto flex gap-4">
            <Link href="/" className="text-sm font-medium text-muted-foreground">
              Dashboard
            </Link>
            <Link href="/vehicles" className="text-sm font-medium">
              Vehicles
            </Link>
            <Link href="/predictions" className="text-sm font-medium text-muted-foreground">
              Predictions
            </Link>
            <Link href="/settings" className="text-sm font-medium text-muted-foreground">
              Settings
            </Link>
          </nav>
        </header>
        <main className="flex-1 p-6">
          <div className="mx-auto max-w-2xl">
            <div className="flex items-center mb-6">
              <Button variant="ghost" size="sm" asChild className="mr-2">
                <Link href="/vehicles">
                  <ArrowLeft className="mr-2 h-4 w-4" />
                  Back
                </Link>
              </Button>
              <h2 className="text-2xl font-bold tracking-tight">Add Vehicle</h2>
            </div>

            <Card>
              <CardHeader>
                <div className="flex items-center justify-center mb-2">
                  <div className="flex h-16 w-16 items-center justify-center rounded-full bg-green-100">
                    <Check className="h-8 w-8 text-green-600" />
                  </div>
                </div>
                <CardTitle className="text-center">Vehicle Added Successfully</CardTitle>
                <CardDescription className="text-center">Your vehicle has been added to the fleet</CardDescription>
              </CardHeader>
              <CardContent className="text-center">
                <p className="text-sm text-muted-foreground mb-6">
                  The vehicle has been added to your fleet and is ready for maintenance prediction.
                </p>
              </CardContent>
              <CardFooter className="flex justify-center gap-4">
                <Button variant="outline" asChild>
                  <Link href="/vehicles/new">Add Another Vehicle</Link>
                </Button>
                <Button asChild>
                  <Link href="/vehicles">View All Vehicles</Link>
                </Button>
              </CardFooter>
            </Card>
          </div>
        </main>
      </div>
    )
  }

  return (
    <div className="flex min-h-screen flex-col">
      <header className="sticky top-0 z-10 flex h-16 items-center gap-4 border-b bg-background px-6">
        <Car className="h-6 w-6" />
        <h1 className="text-lg font-semibold">Vehicle Maintenance Predictor</h1>
        <nav className="ml-auto flex gap-4">
          <Link href="/" className="text-sm font-medium text-muted-foreground">
            Dashboard
          </Link>
          <Link href="/vehicles" className="text-sm font-medium">
            Vehicles
          </Link>
          <Link href="/predictions" className="text-sm font-medium text-muted-foreground">
            Predictions
          </Link>
          <Link href="/settings" className="text-sm font-medium text-muted-foreground">
            Settings
          </Link>
        </nav>
      </header>
      <main className="flex-1 p-6">
        <div className="mx-auto max-w-2xl">
          <div className="flex items-center mb-6">
            <Button variant="ghost" size="sm" asChild className="mr-2">
              <Link href="/vehicles">
                <ArrowLeft className="mr-2 h-4 w-4" />
                Back
              </Link>
            </Button>
            <h2 className="text-2xl font-bold tracking-tight">Add New Vehicle</h2>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Vehicle Information</CardTitle>
              <CardDescription>Enter the details of the vehicle you want to add to your fleet</CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="grid gap-6">
                <div className="grid grid-cols-2 gap-4">
                  <div className="grid gap-2">
                    <Label htmlFor="make">Make</Label>
                    <Select required>
                      <SelectTrigger id="make">
                        <SelectValue placeholder="Select make" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="toyota">Toyota</SelectItem>
                        <SelectItem value="honda">Honda</SelectItem>
                        <SelectItem value="ford">Ford</SelectItem>
                        <SelectItem value="chevrolet">Chevrolet</SelectItem>
                        <SelectItem value="nissan">Nissan</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="grid gap-2">
                    <Label htmlFor="model">Model</Label>
                    <Input id="model" placeholder="Enter model" required />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="grid gap-2">
                    <Label htmlFor="year">Year</Label>
                    <Select required>
                      <SelectTrigger id="year">
                        <SelectValue placeholder="Select year" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="2023">2023</SelectItem>
                        <SelectItem value="2022">2022</SelectItem>
                        <SelectItem value="2021">2021</SelectItem>
                        <SelectItem value="2020">2020</SelectItem>
                        <SelectItem value="2019">2019</SelectItem>
                        <SelectItem value="2018">2018</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="grid gap-2">
                    <Label htmlFor="license">License Plate</Label>
                    <Input id="license" placeholder="Enter license plate" required />
                  </div>
                </div>

                <div className="grid gap-2">
                  <Label htmlFor="mileage">Current Mileage</Label>
                  <Input id="mileage" type="number" placeholder="Enter current mileage" required />
                </div>

                <div className="grid gap-2">
                  <Label htmlFor="last-maintenance">Last Maintenance Date</Label>
                  <Input id="last-maintenance" type="date" required />
                </div>

                <div className="grid gap-2">
                  <Label>Typical Driving Environment</Label>
                  <div className="grid grid-cols-3 gap-2">
                    <div className="flex items-center space-x-2">
                      <input type="checkbox" id="urban" className="rounded border-gray-300" />
                      <label htmlFor="urban" className="text-sm">
                        Urban
                      </label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <input type="checkbox" id="highway" className="rounded border-gray-300" />
                      <label htmlFor="highway" className="text-sm">
                        Highway
                      </label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <input type="checkbox" id="rural" className="rounded border-gray-300" />
                      <label htmlFor="rural" className="text-sm">
                        Rural
                      </label>
                    </div>
                  </div>
                </div>

                <div className="grid gap-2">
                  <Label>Driving Style</Label>
                  <RadioGroup value={drivingStyle} onValueChange={setDrivingStyle} className="grid grid-cols-3 gap-2">
                    <div>
                      <RadioGroupItem value="conservative" id="conservative" className="peer sr-only" />
                      <Label
                        htmlFor="conservative"
                        className="flex flex-col items-center justify-between rounded-md border-2 border-muted bg-popover p-4 hover:bg-accent hover:text-accent-foreground peer-data-[state=checked]:border-primary [&:has([data-state=checked])]:border-primary"
                      >
                        <span>Conservative</span>
                      </Label>
                    </div>
                    <div>
                      <RadioGroupItem value="moderate" id="moderate" className="peer sr-only" />
                      <Label
                        htmlFor="moderate"
                        className="flex flex-col items-center justify-between rounded-md border-2 border-muted bg-popover p-4 hover:bg-accent hover:text-accent-foreground peer-data-[state=checked]:border-primary [&:has([data-state=checked])]:border-primary"
                      >
                        <span>Moderate</span>
                      </Label>
                    </div>
                    <div>
                      <RadioGroupItem value="aggressive" id="aggressive" className="peer sr-only" />
                      <Label
                        htmlFor="aggressive"
                        className="flex flex-col items-center justify-between rounded-md border-2 border-muted bg-popover p-4 hover:bg-accent hover:text-accent-foreground peer-data-[state=checked]:border-primary [&:has([data-state=checked])]:border-primary"
                      >
                        <span>Aggressive</span>
                      </Label>
                    </div>
                  </RadioGroup>
                </div>

                <Button type="submit" className="w-full">
                  Add Vehicle
                </Button>
              </form>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  )
}
