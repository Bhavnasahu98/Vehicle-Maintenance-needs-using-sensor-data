import Link from "next/link"
import { ArrowRight, Car, ChevronRight, Clock, Gauge, Settings, Wrench } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import VehicleStatusChart from "@/components/vehicle-status-chart"
import MaintenancePredictionTable from "@/components/maintenance-prediction-table"

export default function Home() {
  return (
    <div className="flex min-h-screen flex-col">
      <header className="sticky top-0 z-10 flex h-16 items-center gap-4 border-b bg-background px-6">
        <Car className="h-6 w-6" />
        <h1 className="text-lg font-semibold">Vehicle Maintenance Predictor</h1>
        <nav className="ml-auto flex gap-4">
          <Link href="/" className="text-sm font-medium">
            Dashboard
          </Link>
          <Link href="/vehicles" className="text-sm font-medium text-muted-foreground">
            Vehicles
          </Link>
          <Link href="/predictions" className="text-sm font-medium text-muted-foreground">
            Predictions
          </Link>
          <Link href="/settings" className="text-sm font-medium text-muted-foreground">
            Settings
          </Link>
        </nav>
      </header>
      <main className="flex-1 p-6">
        <div className="grid gap-6">
          <div className="flex items-center justify-between">
            <h2 className="text-2xl font-bold tracking-tight">Dashboard</h2>
            <div className="flex items-center gap-2">
              <Button variant="outline" size="sm">
                <Clock className="mr-2 h-4 w-4" />
                Last updated: Today, 2:30 PM
              </Button>
              <Button size="sm">
                <Settings className="mr-2 h-4 w-4" />
                Settings
              </Button>
            </div>
          </div>
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-sm font-medium">Total Vehicles</CardTitle>
                <Car className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">12</div>
                <p className="text-xs text-muted-foreground">+2 from last month</p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-sm font-medium">Maintenance Due</CardTitle>
                <Wrench className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">3</div>
                <p className="text-xs text-muted-foreground">Within next 30 days</p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-sm font-medium">Average Mileage</CardTitle>
                <Gauge className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">45,892</div>
                <p className="text-xs text-muted-foreground">+12% from last year</p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-sm font-medium">Prediction Accuracy</CardTitle>
                <Settings className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">92%</div>
                <p className="text-xs text-muted-foreground">+2% from last quarter</p>
              </CardContent>
            </Card>
          </div>
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-7">
            <Card className="col-span-4">
              <CardHeader>
                <CardTitle>Vehicle Status Overview</CardTitle>
                <CardDescription>Maintenance prediction status for all vehicles in the fleet</CardDescription>
              </CardHeader>
              <CardContent className="pl-2">
                <VehicleStatusChart />
              </CardContent>
            </Card>
            <Card className="col-span-3">
              <CardHeader>
                <CardTitle>Upcoming Maintenance</CardTitle>
                <CardDescription>Vehicles requiring maintenance in the next 30 days</CardDescription>
              </CardHeader>
              <CardContent>
                <MaintenancePredictionTable />
              </CardContent>
              <CardFooter>
                <Button asChild className="w-full">
                  <Link href="/predictions">
                    View All Predictions
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </Link>
                </Button>
              </CardFooter>
            </Card>
          </div>
          <div className="grid gap-6 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle>Add New Vehicle</CardTitle>
                <CardDescription>Add a new vehicle to your fleet for maintenance prediction</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">
                  Add vehicle details including make, model, year, and current mileage to start tracking and predicting
                  maintenance needs.
                </p>
              </CardContent>
              <CardFooter>
                <Button asChild variant="outline">
                  <Link href="/vehicles/new">
                    Add Vehicle
                    <ChevronRight className="ml-2 h-4 w-4" />
                  </Link>
                </Button>
              </CardFooter>
            </Card>
            <Card>
              <CardHeader>
                <CardTitle>Run Prediction</CardTitle>
                <CardDescription>Generate new maintenance predictions for your fleet</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">
                  Update your maintenance predictions based on the latest vehicle data and usage patterns.
                </p>
              </CardContent>
              <CardFooter>
                <Button asChild>
                  <Link href="/predictions/generate">
                    Generate Predictions
                    <ChevronRight className="ml-2 h-4 w-4" />
                  </Link>
                </Button>
              </CardFooter>
            </Card>
          </div>
        </div>
      </main>
    </div>
  )
}
