import Link from "next/link"
import { Car, Download, Filter, Play, Search } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"

export default function PredictionsPage() {
  const predictions = [
    {
      id: "1",
      vehicle: "Toyota Camry",
      plate: "ABC-1234",
      maintenanceType: "Oil Change",
      dueDate: "May 15, 2025",
      confidence: "High",
      status: "Upcoming",
    },
    {
      id: "2",
      vehicle: "Ford F-150",
      plate: "XYZ-5678",
      maintenanceType: "Brake Service",
      dueDate: "May 22, 2025",
      confidence: "Medium",
      status: "Upcoming",
    },
    {
      id: "3",
      vehicle: "Honda CR-V",
      plate: "DEF-9012",
      maintenanceType: "Tire Rotation",
      dueDate: "June 5, 2025",
      confidence: "High",
      status: "Scheduled",
    },
    {
      id: "4",
      vehicle: "Chevrolet Silverado",
      plate: "GHI-3456",
      maintenanceType: "Transmission Service",
      dueDate: "May 10, 2025",
      confidence: "High",
      status: "Overdue",
    },
    {
      id: "5",
      vehicle: "Nissan Altima",
      plate: "JKL-7890",
      maintenanceType: "Air Filter Replacement",
      dueDate: "July 12, 2025",
      confidence: "Medium",
      status: "Scheduled",
    },
  ]

  return (
    <div className="flex min-h-screen flex-col">
      <header className="sticky top-0 z-10 flex h-16 items-center gap-4 border-b bg-background px-6">
        <Car className="h-6 w-6" />
        <h1 className="text-lg font-semibold">Vehicle Maintenance Predictor</h1>
        <nav className="ml-auto flex gap-4">
          <Link href="/" className="text-sm font-medium text-muted-foreground">
            Dashboard
          </Link>
          <Link href="/vehicles" className="text-sm font-medium text-muted-foreground">
            Vehicles
          </Link>
          <Link href="/predictions" className="text-sm font-medium">
            Predictions
          </Link>
          <Link href="/settings" className="text-sm font-medium text-muted-foreground">
            Settings
          </Link>
        </nav>
      </header>
      <main className="flex-1 p-6">
        <div className="grid gap-6">
          <div className="flex items-center justify-between">
            <h2 className="text-2xl font-bold tracking-tight">Maintenance Predictions</h2>
            <div className="flex gap-2">
              <Button variant="outline">
                <Download className="mr-2 h-4 w-4" />
                Export
              </Button>
              <Button>
                <Play className="mr-2 h-4 w-4" />
                Run Prediction
              </Button>
            </div>
          </div>
          <Card>
            <CardHeader>
              <CardTitle>Predicted Maintenance</CardTitle>
              <CardDescription>Machine learning predictions for upcoming vehicle maintenance</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex items-center gap-4 mb-6">
                <div className="relative flex-1">
                  <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                  <Input type="search" placeholder="Search predictions..." className="pl-8" />
                </div>
                <Button variant="outline" size="icon">
                  <Filter className="h-4 w-4" />
                  <span className="sr-only">Filter</span>
                </Button>
              </div>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Vehicle</TableHead>
                    <TableHead>Maintenance Type</TableHead>
                    <TableHead>Due Date</TableHead>
                    <TableHead>Confidence</TableHead>
                    <TableHead>Status</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {predictions.map((prediction) => (
                    <TableRow key={prediction.id}>
                      <TableCell className="font-medium">
                        <div className="flex flex-col">
                          <span>{prediction.vehicle}</span>
                          <span className="text-xs text-muted-foreground">{prediction.plate}</span>
                        </div>
                      </TableCell>
                      <TableCell>{prediction.maintenanceType}</TableCell>
                      <TableCell>{prediction.dueDate}</TableCell>
                      <TableCell>{prediction.confidence}</TableCell>
                      <TableCell>
                        <span
                          className={`inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium ${
                            prediction.status === "Scheduled"
                              ? "bg-green-100 text-green-800"
                              : prediction.status === "Upcoming"
                                ? "bg-yellow-100 text-yellow-800"
                                : "bg-red-100 text-red-800"
                          }`}
                        >
                          {prediction.status}
                        </span>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  )
}
