"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, Car, Check, ChevronRight, Loader2 } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Checkbox } from "@/components/ui/checkbox"
import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Separator } from "@/components/ui/separator"
import { Slider } from "@/components/ui/slider"
import { runPredictionModel } from "@/lib/prediction-model"

export default function GeneratePredictionsPage() {
  const [predictionType, setPredictionType] = useState("all")
  const [timeframe, setTimeframe] = useState("90")
  const [confidenceThreshold, setConfidenceThreshold] = useState([70])
  const [isRunning, setIsRunning] = useState(false)
  const [isComplete, setIsComplete] = useState(false)

  const handleRunPrediction = async () => {
    setIsRunning(true)

    try {
      // Simulate running the prediction model
      await new Promise((resolve) => setTimeout(resolve, 3000))
      await runPredictionModel({
        predictionType,
        timeframe: Number.parseInt(timeframe),
        confidenceThreshold: confidenceThreshold[0],
      })

      setIsComplete(true)
    } catch (error) {
      console.error("Error running prediction:", error)
    } finally {
      setIsRunning(false)
    }
  }

  return (
    <div className="flex min-h-screen flex-col">
      <header className="sticky top-0 z-10 flex h-16 items-center gap-4 border-b bg-background px-6">
        <Car className="h-6 w-6" />
        <h1 className="text-lg font-semibold">Vehicle Maintenance Predictor</h1>
        <nav className="ml-auto flex gap-4">
          <Link href="/" className="text-sm font-medium text-muted-foreground">
            Dashboard
          </Link>
          <Link href="/vehicles" className="text-sm font-medium text-muted-foreground">
            Vehicles
          </Link>
          <Link href="/predictions" className="text-sm font-medium">
            Predictions
          </Link>
          <Link href="/settings" className="text-sm font-medium text-muted-foreground">
            Settings
          </Link>
        </nav>
      </header>
      <main className="flex-1 p-6">
        <div className="mx-auto max-w-2xl">
          <div className="flex items-center mb-6">
            <Button variant="ghost" size="sm" asChild className="mr-2">
              <Link href="/predictions">
                <ArrowLeft className="mr-2 h-4 w-4" />
                Back
              </Link>
            </Button>
            <h2 className="text-2xl font-bold tracking-tight">Generate Predictions</h2>
          </div>

          {isComplete ? (
            <Card>
              <CardHeader>
                <div className="flex items-center justify-center mb-2">
                  <div className="flex h-16 w-16 items-center justify-center rounded-full bg-green-100">
                    <Check className="h-8 w-8 text-green-600" />
                  </div>
                </div>
                <CardTitle className="text-center">Prediction Complete</CardTitle>
                <CardDescription className="text-center">
                  Your maintenance predictions have been successfully generated
                </CardDescription>
              </CardHeader>
              <CardContent className="text-center">
                <p className="text-sm text-muted-foreground mb-6">
                  The model has analyzed your vehicle data and generated maintenance predictions based on your
                  parameters.
                </p>
                <div className="grid grid-cols-3 gap-4 mb-6">
                  <div className="rounded-lg border p-3">
                    <div className="text-2xl font-bold">8</div>
                    <div className="text-xs text-muted-foreground">Predictions</div>
                  </div>
                  <div className="rounded-lg border p-3">
                    <div className="text-2xl font-bold">3</div>
                    <div className="text-xs text-muted-foreground">High Priority</div>
                  </div>
                  <div className="rounded-lg border p-3">
                    <div className="text-2xl font-bold">92%</div>
                    <div className="text-xs text-muted-foreground">Confidence</div>
                  </div>
                </div>
              </CardContent>
              <CardFooter className="flex justify-center gap-4">
                <Button variant="outline" asChild>
                  <Link href="/predictions/generate">Run Again</Link>
                </Button>
                <Button asChild>
                  <Link href="/predictions">
                    View Predictions
                    <ChevronRight className="ml-2 h-4 w-4" />
                  </Link>
                </Button>
              </CardFooter>
            </Card>
          ) : (
            <Card>
              <CardHeader>
                <CardTitle>Prediction Parameters</CardTitle>
                <CardDescription>Configure the parameters for the maintenance prediction model</CardDescription>
              </CardHeader>
              <CardContent className="grid gap-6">
                <div className="grid gap-2">
                  <Label htmlFor="prediction-type">Prediction Type</Label>
                  <RadioGroup
                    id="prediction-type"
                    value={predictionType}
                    onValueChange={setPredictionType}
                    className="grid grid-cols-3 gap-2"
                  >
                    <div>
                      <RadioGroupItem value="all" id="all" className="peer sr-only" />
                      <Label
                        htmlFor="all"
                        className="flex flex-col items-center justify-between rounded-md border-2 border-muted bg-popover p-4 hover:bg-accent hover:text-accent-foreground peer-data-[state=checked]:border-primary [&:has([data-state=checked])]:border-primary"
                      >
                        <span>All</span>
                      </Label>
                    </div>
                    <div>
                      <RadioGroupItem value="routine" id="routine" className="peer sr-only" />
                      <Label
                        htmlFor="routine"
                        className="flex flex-col items-center justify-between rounded-md border-2 border-muted bg-popover p-4 hover:bg-accent hover:text-accent-foreground peer-data-[state=checked]:border-primary [&:has([data-state=checked])]:border-primary"
                      >
                        <span>Routine</span>
                      </Label>
                    </div>
                    <div>
                      <RadioGroupItem value="major" id="major" className="peer sr-only" />
                      <Label
                        htmlFor="major"
                        className="flex flex-col items-center justify-between rounded-md border-2 border-muted bg-popover p-4 hover:bg-accent hover:text-accent-foreground peer-data-[state=checked]:border-primary [&:has([data-state=checked])]:border-primary"
                      >
                        <span>Major</span>
                      </Label>
                    </div>
                  </RadioGroup>
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="timeframe">Prediction Timeframe</Label>
                  <Select value={timeframe} onValueChange={setTimeframe}>
                    <SelectTrigger id="timeframe">
                      <SelectValue placeholder="Select timeframe" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="30">Next 30 days</SelectItem>
                      <SelectItem value="60">Next 60 days</SelectItem>
                      <SelectItem value="90">Next 90 days</SelectItem>
                      <SelectItem value="180">Next 6 months</SelectItem>
                      <SelectItem value="365">Next year</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="grid gap-2">
                  <div className="flex items-center justify-between">
                    <Label htmlFor="confidence">Confidence Threshold: {confidenceThreshold}%</Label>
                  </div>
                  <Slider
                    id="confidence"
                    min={50}
                    max={95}
                    step={5}
                    value={confidenceThreshold}
                    onValueChange={setConfidenceThreshold}
                  />
                  <p className="text-xs text-muted-foreground">
                    Only show predictions with at least this confidence level
                  </p>
                </div>
                <Separator />
                <div className="grid gap-2">
                  <Label>Advanced Options</Label>
                  <div className="flex items-center space-x-2">
                    <Checkbox id="include-historical" />
                    <label
                      htmlFor="include-historical"
                      className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                    >
                      Include historical data in prediction
                    </label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Checkbox id="seasonal-factors" />
                    <label
                      htmlFor="seasonal-factors"
                      className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                    >
                      Consider seasonal factors
                    </label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Checkbox id="driver-behavior" />
                    <label
                      htmlFor="driver-behavior"
                      className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                    >
                      Include driver behavior analysis
                    </label>
                  </div>
                </div>
              </CardContent>
              <CardFooter>
                <Button onClick={handleRunPrediction} disabled={isRunning} className="w-full">
                  {isRunning ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Running Prediction...
                    </>
                  ) : (
                    "Generate Predictions"
                  )}
                </Button>
              </CardFooter>
            </Card>
          )}
        </div>
      </main>
    </div>
  )
}
