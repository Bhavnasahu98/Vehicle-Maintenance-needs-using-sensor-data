import numpy as np
from datetime import datetime, timedelta
from sklearn.ensemble import RandomForestClassifier
import pickle
import os

# Check if a trained model exists, otherwise create a new one
MODEL_PATH = 'maintenance_model.pkl'

def get_model():
    if os.path.exists(MODEL_PATH):
        with open(MODEL_PATH, 'rb') as f:
            model = pickle.load(f)
    else:
        # Create and train a simple model with dummy data
        model = RandomForestClassifier(n_estimators=100, random_state=42)
        
        # Generate some dummy training data
        X_train = np.random.rand(100, 7)  # 7 features
        y_train = np.random.randint(0, 2, size=100)  # Binary classification
        
        model.fit(X_train, y_train)
        
        # Save the model
        with open(MODEL_PATH, 'wb') as f:
            pickle.dump(model, f)
    
    return model

def preprocess_vehicle_data(vehicle_data):
    """
    Preprocess vehicle data for the ML model
    """
    current_date = datetime.now()
    
    # Calculate vehicle age in years
    vehicle_age = current_date.year - vehicle_data['year']
    
    # Calculate days since last maintenance
    last_maintenance = vehicle_data['last_maintenance_date']
    if isinstance(last_maintenance, str):
        last_maintenance = datetime.strptime(last_maintenance, '%Y-%m-%d')
    days_since_maintenance = (current_date - last_maintenance).days
    
    # Calculate maintenance frequency (if history exists)
    maintenance_history = vehicle_data.get('maintenance_history', [])
    maintenance_frequency = len(maintenance_history) / max(1, vehicle_age)
    
    # Get usage pattern
    usage_pattern = vehicle_data.get('usage_pattern', {})
    driving_style = usage_pattern.get('driving_style', 'moderate')
    environments = usage_pattern.get('environments', [])
    avg_daily_miles = usage_pattern.get('avg_daily_miles', 30)
    
    # Convert driving style to numeric factor
    driving_style_factor = 0.5  # moderate
    if driving_style == 'aggressive':
        driving_style_factor = 0.8
    elif driving_style == 'conservative':
        driving_style_factor = 0.3
    
    # Environmental factor
    environmental_factor = 0.5
    if 'urban' in environments:
        environmental_factor = 0.7
    elif 'highway' in environments:
        environmental_factor = 0.4
    
    # Normalize features
    features = [
        vehicle_age / 10,  # Normalize age
        vehicle_data['mileage'] / 100000,  # Normalize mileage
        days_since_maintenance / 365,  # Normalize days since maintenance
        maintenance_frequency / 5,  # Normalize maintenance frequency
        avg_daily_miles / 100,  # Normalize daily miles
        driving_style_factor,
        environmental_factor
    ]
    
    return np.array(features).reshape(1, -1)

def predict_maintenance(vehicle_data, prediction_type='all', timeframe=90, 
                        confidence_threshold=70, include_historical=False,
                        seasonal_factors=False, driver_behavior=False):
    """
    Predict maintenance needs for a vehicle
    """
    # Get the model
    model = get_model()
    
    # Preprocess the data
    features = preprocess_vehicle_data(vehicle_data)
    
    # Make prediction (probability of needing maintenance)
    maintenance_prob = model.predict_proba(features)[0][1]
    
    # If probability is below threshold, return empty list
    if maintenance_prob * 100 < confidence_threshold:
        return []
    
    # Calculate due date based on prediction and timeframe
    days_to_add = int(maintenance_prob * timeframe)
    due_date = datetime.now() + timedelta(days=days_to_add)
    
    # Determine maintenance type based on mileage and history
    mileage = vehicle_data['mileage']
    maintenance_type = "Oil Change"  # Default
    
    if mileage > 30000 and mileage < 40000:
        maintenance_type = "Brake Service"
    elif mileage > 40000 and mileage < 60000:
        maintenance_type = "Transmission Service"
    elif mileage % 5000 < 500:
        maintenance_type = "Tire Rotation"
    
    # Filter by prediction type if needed
    if prediction_type != 'all':
        major_types = ["Transmission Service", "Engine Service", "Brake Service"]
        is_major = maintenance_type in major_types
        if (prediction_type == 'major' and not is_major) or (prediction_type == 'routine' and is_major):
            return []
    
    # Format confidence level
    confidence_level = "Medium"
    if maintenance_prob > 0.8:
        confidence_level = "High"
    elif maintenance_prob < 0.6:
        confidence_level = "Low"
    
    return [{
        'vehicle_id': vehicle_data['id'],
        'maintenance_type': maintenance_type,
        'due_date': due_date.strftime('%Y-%m-%d'),
        'confidence': confidence_level
    }]
