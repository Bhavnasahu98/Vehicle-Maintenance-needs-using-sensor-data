"use client"

import { Bar, BarChart, CartesianGrid, Legend, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts"

import { ChartContainer, ChartTooltipContent } from "@/components/ui/chart"

const data = [
  {
    name: "Sedan",
    healthy: 4,
    warning: 1,
    critical: 0,
  },
  {
    name: "SUV",
    healthy: 2,
    warning: 1,
    critical: 1,
  },
  {
    name: "Truck",
    healthy: 1,
    warning: 0,
    critical: 1,
  },
  {
    name: "Van",
    healthy: 1,
    warning: 0,
    critical: 0,
  },
]

export default function VehicleStatusChart() {
  return (
    <ChartContainer
      config={{
        healthy: {
          label: "Healthy",
          color: "hsl(var(--success))",
        },
        warning: {
          label: "Maintenance Soon",
          color: "hsl(var(--warning))",
        },
        critical: {
          label: "Maintenance Due",
          color: "hsl(var(--destructive))",
        },
      }}
      className="h-[300px]"
    >
      <ResponsiveContainer width="100%" height="100%">
        <BarChart data={data} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis dataKey="name" />
          <YAxis allowDecimals={false} />
          <Tooltip content={<ChartTooltipContent />} />
          <Legend />
          <Bar dataKey="healthy" stackId="a" fill="var(--color-healthy)" radius={[4, 4, 0, 0]} />
          <Bar dataKey="warning" stackId="a" fill="var(--color-warning)" radius={[4, 4, 0, 0]} />
          <Bar dataKey="critical" stackId="a" fill="var(--color-critical)" radius={[4, 4, 0, 0]} />
        </BarChart>
      </ResponsiveContainer>
    </ChartContainer>
  )
}
