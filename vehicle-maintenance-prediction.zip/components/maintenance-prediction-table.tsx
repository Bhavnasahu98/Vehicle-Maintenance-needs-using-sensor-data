import { Car, ChevronRight } from "lucide-react"
import Link from "next/link"

import { Button } from "@/components/ui/button"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"

export default function MaintenancePredictionTable() {
  const predictions = [
    {
      id: "1",
      vehicle: "Toyota Camry",
      plate: "ABC-1234",
      maintenanceType: "Oil Change",
      dueDate: "May 15, 2025",
      confidence: "High",
    },
    {
      id: "2",
      vehicle: "Ford F-150",
      plate: "XYZ-5678",
      maintenanceType: "Brake Service",
      dueDate: "May 22, 2025",
      confidence: "Medium",
    },
    {
      id: "3",
      vehicle: "Honda CR-V",
      plate: "DEF-9012",
      maintenanceType: "Tire Rotation",
      dueDate: "June 5, 2025",
      confidence: "High",
    },
  ]

  return (
    <Table>
      <TableHeader>
        <TableRow>
          <TableHead>Vehicle</TableHead>
          <TableHead>Maintenance</TableHead>
          <TableHead>Due Date</TableHead>
          <TableHead className="text-right">Action</TableHead>
        </TableRow>
      </TableHeader>
      <TableBody>
        {predictions.map((prediction) => (
          <TableRow key={prediction.id}>
            <TableCell className="font-medium">
              <div className="flex items-center">
                <Car className="mr-2 h-4 w-4 text-muted-foreground" />
                <div>
                  <div>{prediction.vehicle}</div>
                  <div className="text-xs text-muted-foreground">{prediction.plate}</div>
                </div>
              </div>
            </TableCell>
            <TableCell>{prediction.maintenanceType}</TableCell>
            <TableCell>
              <div className="flex flex-col">
                <span>{prediction.dueDate}</span>
                <span className="text-xs text-muted-foreground">{prediction.confidence} confidence</span>
              </div>
            </TableCell>
            <TableCell className="text-right">
              <Button variant="ghost" size="icon" asChild>
                <Link href={`/predictions/${prediction.id}`}>
                  <ChevronRight className="h-4 w-4" />
                  <span className="sr-only">View details</span>
                </Link>
              </Button>
            </TableCell>
          </TableRow>
        ))}
      </TableBody>
    </Table>
  )
}
